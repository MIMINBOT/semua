let handler = async m => m.reply(`
┏━━°❀❬ *INFO BOT* ❭❀°━━┓
┃
┣➥ *Nama bot:MIMIN X BOT*
┣➥ *Author:Ibnu*
┣➥ *Owner:Ibnu*
┣➥ *Script: Ibnu NR*
┣➥ *Wa.me/628989031500*
┃
┣━━°❀❬ *TQTO* ❭❀°━━┓
┃
┣➥ *Nurotomo*
┣➥ *MfarelS*
┣➥ *ST4RZ*
┣➥ *Drawl Nag*
┣➥ *Dan kawan yang lain :)*
┃
┣━━°❀❬ *DONASI* ❭❀°━━┓
┣➥ *M3: 0858-0310-7598*
┣➥ *3: 0898-9041-500*
┣➥ *DANA: 0898-9031-500*
┣━━━━━━━━━━━━━━━━━━━━
┃ *POWERED IBNU NR*
┗━━━━━━━━━━━━━━━━━━━━
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
